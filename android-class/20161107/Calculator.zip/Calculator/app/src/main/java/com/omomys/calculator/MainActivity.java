package com.omomys.calculator;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Stack;

public class MainActivity extends ActionBarActivity {

    private Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
    private Button btnC, btnO, btnD, btnM, btnS, btnP, btnE;
    private TextView display, op;
    private double value, buffer;
    private char operator;
    boolean error, period;
    int periodPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn0);
        btn3 = (Button) findViewById(R.id.btn0);
        btn4 = (Button) findViewById(R.id.btn0);
        btn5 = (Button) findViewById(R.id.btn0);
        btn6 = (Button) findViewById(R.id.btn0);
        btn7 = (Button) findViewById(R.id.btn0);
        btn8 = (Button) findViewById(R.id.btn0);
        btn9 = (Button) findViewById(R.id.btn0);
        btnO = (Button) findViewById(R.id.btnO);
        btnM = (Button) findViewById(R.id.btnM);
        btnP = (Button) findViewById(R.id.btnP);
        btnE = (Button) findViewById(R.id.btnE);
        btnS = (Button) findViewById(R.id.btnS);
        btnD = (Button) findViewById(R.id.btnD);
        display = (TextView) findViewById(R.id.display);
        op = (TextView) findViewById(R.id.operator);
        value = 0;
        buffer = 0;
        operator = ' ';
        error = false;
        period = false;
        periodPos = 0;
    }

    public void buttonClick(View view){

        Button btn = (Button) view; //type casting

        switch(btn.getId()){
            case R.id.btn0:
            case R.id.btn1:
            case R.id.btn2:
            case R.id.btn3:
            case R.id.btn4:
            case R.id.btn5:
            case R.id.btn6:
            case R.id.btn7:
            case R.id.btn8:
            case R.id.btn9:
                if(period){
                    periodPos += 1;
                    value += Double.parseDouble(btn.getText().toString()) / Math.pow(10, periodPos);
                }
                else {
                    if (value == 0)
                        value += Double.parseDouble(btn.getText().toString());
                    else
                        value = value * 10 + Double.parseDouble(btn.getText().toString());
                }
                op.setText(" ");
                break;

            case R.id.btnC:
                value = 0;
                buffer = 0;
                operator = ' ';
                error = false;
                period = false;
                periodPos = 0;
                op.setText(" ");
                break;

            case R.id.btnP:
                buffer = value;
                value = 0;
                operator = '+';
                period = false;
                op.setText("+");
                break;

            case R.id.btnS:
                buffer = value;
                value = 0;
                operator = '-';
                period = false;
                op.setText("-");
                break;

            case R.id.btnM:
                buffer = value;
                value = 0;
                operator = '*';
                period = false;
                op.setText("*");
                break;

            case R.id.btnD:
                buffer = value;
                value = 0;
                operator = '/';
                period = false;
                op.setText("/");
                break;

            case R.id.btnE:
                switch(operator){
                    case '+':
                        value += buffer;
                        break;
                    case '-':
                        value = buffer - value;
                        break;
                    case '*':
                        value *= buffer;
                        break;
                    case '/':
                        if(value == 0)
                            error = true;
                        else
                            value = buffer / value;
                        break;
                }
                op.setText("=");
                period = false;
                buffer = value;
                break;

            case R.id.btnO:
                period = true;
                break;

        }
        if(error)
            display.setText(R.string.cal_error);
        else
            display.setText(String.valueOf(value));
    }

}
