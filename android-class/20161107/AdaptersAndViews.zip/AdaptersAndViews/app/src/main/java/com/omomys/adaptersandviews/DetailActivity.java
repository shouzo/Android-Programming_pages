package com.omomys.adaptersandviews;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        TextView tv = (TextView) findViewById(R.id.tv_data);
        int data = getIntent().getIntExtra("data", 0);
        tv.setText(String.valueOf(data));
    }
}
