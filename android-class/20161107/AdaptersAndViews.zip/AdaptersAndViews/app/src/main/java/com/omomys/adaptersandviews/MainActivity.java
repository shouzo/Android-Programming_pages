package com.omomys.adaptersandviews;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import org.w3c.dom.Text;

import java.util.ArrayList;

import static android.widget.ArrayAdapter.createFromResource;

public class MainActivity extends AppCompatActivity {

    private String[] title = {"Data1", "Data2", "Data3", "Data4", "Data5",
            "Data6", "Data7", "Data8", "Data9", "Data10",
            "Data11", "Data12", "Data13", "Data14", "Data15",
            "Data16", "Data17", "Data18", "Data19", "Data20"};
    private int[] data = {R.drawable.ic_cake_black_36dp, R.drawable.ic_domain_black_36dp, R.drawable.ic_group_add_black_36dp,
        R.drawable.ic_group_black_36dp};


    private ArrayList<String> al = new ArrayList<String>();
    private int currentPos = 0;

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        GridView gvItemList = (GridView) findViewById(R.id.gv_item_list);
        //ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, title);
        //ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(this, R.array.dataArray, android.R.layout.simple_spinner_item);
        //gvItemList.setAdapter(arrayAdapter);
        ImageViewAdapter imgAdapter = new ImageViewAdapter();
        gvItemList.setAdapter(imgAdapter);
        gvItemList.setOnItemClickListener(new bobItemClickListener());
/*
        Spinner spItemList = (Spinner) findViewById(R.id.sp_item_list);
        //ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, title);
        ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(this, R.array.dataArray, android.R.layout.simple_spinner_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spItemList.setAdapter(arrayAdapter);
        spItemList.setOnItemSelectedListener(new bobItemSelectedListener());

        ListView lvItemList = (ListView) findViewById(R.id.lv_item_list);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, title);
        lvItemList.setAdapter(arrayAdapter);
        lvItemList.setOnItemClickListener(new bobItemClickListener());
     */

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(toolbar, "New Item", Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show();
            }
        });

    }


    class bobItemClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("data", position);
            startActivity(intent);
        }
    }

    class bobItemSelectedListener implements AdapterView.OnItemSelectedListener {


        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("data", position);
            startActivity(intent);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }

    class ImageViewAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            //return al.size();
            return title.length;
        }

        @Override
        public Object getItem(int position) {
            //return al.get(position);
            return title[position];
        }

        @Override
        public long getItemId(int position) {
            return data[position%4];
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View row = convertView;

            if(row == null){
                row = getLayoutInflater().inflate(R.layout.grid_view_item, null);
                ImageView imgv = (ImageView) row.findViewById(R.id.iv_grid_item_image);
                TextView tv = (TextView) row.findViewById(R.id.tv_grid_item_text);
                imgv.setImageResource(data[position%4]);
                tv.setText(title[position]);
                //tv.setText(al.get(position));
            }

            return row;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Snackbar.make(toolbar, "Settings", Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show();
            return true;
        }

        if (id == R.id.action_help) {
            Snackbar.make(toolbar, "Help", Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
