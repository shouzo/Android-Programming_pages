package com.omomys.beeper;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends ActionBarActivity {

    private Button btnStart, btnStop;
    private Intent intt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnStart = (Button) findViewById(R.id.btn_start);
        btnStop = (Button) findViewById(R.id.btn_stop);
        intt =  new Intent(MainActivity.this, CountingService.class);
        //intt.putExtra("TIME", 60);
    }

    public void onButtonClick(View view){
        Button btn = (Button) view;
        switch(btn.getId()){
            case R.id.btn_start:
                btnStart.setEnabled(false);
                btnStop.setEnabled(true);
                startService(intt);
                break;
            case R.id.btn_stop:
                btnStop.setEnabled(false);
                btnStart.setEnabled(true);
                stopService(intt);
                break;
        }
    }

    public void onDestroy(){
        super.onDestroy();
    }
}
