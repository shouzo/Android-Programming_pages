package com.omomys.beeper;

import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Bob on 2015/11/1.
 */
public class CountingService extends Service {

    private Handler handler;
    private CountDown cd;
    int time, beepId;
    private SoundPool sp;

    @Override
    public IBinder onBind(Intent intt){
        return null;
    }

    @Override
    public void onCreate(){
        super.onCreate();
        cd = new CountDown();
        handler = new Handler();
        sp = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        beepId = sp.load(this, R.raw.censor_beep, 1);
    }

    @Override
    public int onStartCommand(Intent intt, int flag, int startId){
        Log.i("CountDown", "onStartCommand");
        //time = intt.getIntExtra("TIME", 0);
        //time *= 1000;
        //cd.setTimeToCountDown(time);
        handler.post(cd);
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy(){
        handler.removeCallbacks(cd);
        sp.release();
        super.onDestroy();
    }

    class CountDown extends Thread{

        @Override
        public void run(){
            super.run();
            try{

                //Log.i("CountDown", Integer.toString(time));
                sp.play(beepId, 1, 1, 0, 0, 1);
                handler.postDelayed(this, 1000);
            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
    }

}
