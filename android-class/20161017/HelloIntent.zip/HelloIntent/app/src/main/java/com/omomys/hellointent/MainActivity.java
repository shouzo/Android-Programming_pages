package com.omomys.hellointent;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private Camera camera;
    private Button btnSplash, btnCamera, btnPhone, btnCal, btnMusic;
    private EditText edtPhoneNumber;
    private TextView ans;
    private ImageView iv;
    private final String TAG = "HelloIntent";
    final int CAMERA = 0;
    final int CAL = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSplash = (Button)findViewById(R.id.btn_splash_screen);
        btnCamera = (Button)findViewById(R.id.btn_camera);
        btnPhone = (Button)findViewById(R.id.btn_phone);
        btnCal = (Button)findViewById(R.id.btn_cal);
        btnMusic = (Button)findViewById(R.id.btn_music);
        edtPhoneNumber = (EditText)findViewById(R.id.edt_phone_number);
        iv = (ImageView)findViewById(R.id.imageView);
        ans = (TextView) findViewById(R.id.ans);

        btnSplash.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View arg0) {
                Intent i = new Intent(MainActivity.this, SplashScreen.class);
                startActivity(i);
            }
        });

        btnCamera.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View arg0) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA);
            }
        });

        btnPhone.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View arg0) {
                String phoneNumber = edtPhoneNumber.getText().toString();
                Uri uri = Uri.parse("tel:" + phoneNumber);
                Intent i = new Intent(Intent.ACTION_CALL, uri);
                startActivity(i);
            }
        });

        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CalActivity.class);
                startActivityForResult(intent, CAL);
            }
        });

        btnMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("file:///sdcard/WeAreTheChampions.mp3");
                intent.setDataAndType(uri, "audio/mp3");
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.i("HelloIntent-request:", Integer.toString(requestCode));
        Log.i("HelloIntent-result:", Integer.toString(resultCode));
        if (requestCode == CAMERA){
                Bundle extras = data.getExtras();
                Bitmap bmp = (Bitmap) extras.get("data");
                iv.setImageBitmap(bmp);
        }
        if(resultCode == CAL){
            String str = data.getStringExtra("answer").toString();
            ans.setText(str);
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "onStart() is called", Toast.LENGTH_SHORT).show();
        Log.i("HelloWorld", "OnStart() is called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(this, "onRestart() is called", Toast.LENGTH_SHORT).show();
        Log.i("HelloWorld", "OnRestart() is called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "onResume() is called", Toast.LENGTH_SHORT).show();
        Log.i("HelloWorld", "OnResume() is called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "onPause() is called", Toast.LENGTH_SHORT).show();
        Log.i("HelloWorld", "OnPause() is called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "onStop() is called", Toast.LENGTH_SHORT).show();
        Log.i("HelloWorld", "OnStop() is called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "onDestroy() is called", Toast.LENGTH_SHORT).show();
        Log.i("HelloWorld", "OnDestroy() is called");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
