package com.omomys.hellointent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CalActivity extends Activity {

    private EditText num1, num2, ans;
    private Button btn_return;
    final int CAL = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal);
        num1 = (EditText) findViewById(R.id.number1);
        num2 = (EditText) findViewById(R.id.number2);
        ans = (EditText) findViewById(R.id.answer);
        btn_return = (Button) findViewById(R.id.btn_return);
        btn_return.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 btn_return.setEnabled(false);
                Intent intent = new Intent();
                ans.setText(Integer.toString(Integer.valueOf(num1.getText().toString()) +
                        Integer.valueOf(num2.getText().toString())));
                intent.putExtra("answer", ans.getText().toString());
                setResult(CAL, intent);
                finish();
             }
             });
    }
}
