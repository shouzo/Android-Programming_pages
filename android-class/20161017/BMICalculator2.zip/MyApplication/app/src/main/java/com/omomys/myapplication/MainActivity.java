package com.omomys.myapplication;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etWeight;
    private EditText etHeight;
    private Button bmiButton;
    private Button helpButton;
    private Double b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
    }

    private void findViews() {
        etWeight = (EditText) findViewById(R.id.et_weight);
        etHeight =  (EditText) findViewById(R.id.et_height);
        bmiButton = (Button) findViewById(R.id.b_bmi);
        helpButton = (Button) findViewById(R.id.b_help);

        bmiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = etWeight.getText().toString();
                String height = etHeight.getText().toString();
                Double w = Double.parseDouble(weight);
                Double h = Double.parseDouble(height);
                b = w/Math.pow(h, 2);

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(getString(R.string.app_name))
                        .setMessage(getString(R.string.dialog_messate)+ ": " + b)
                        .setPositiveButton(getString(R.string.button_ok), null)
                        .setNegativeButton(getString(R.string.button_no), null)
                        .setNeutralButton(getString(R.string.button_cancel), null)
                        .show();
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                //intent.putExtra("message", "This is the screen for help");
                //intent.putExtra("bmi", b);
                Bundle bundle = new Bundle();
                bundle.putString("message", "This is the screen for help(from bundle)");
                bundle.putDouble("bmi", b);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    public void bmi(View v){
        String weight = etWeight.getText().toString();
        String height = etHeight.getText().toString();
        double w = Double.parseDouble(weight);
        double h = Double.parseDouble(height);
        b = w/Math.pow(h, 2);
        Toast.makeText(this, Double.toString(b), Toast.LENGTH_LONG).show();
        Log.d("Height", Double.toString(b));
    }

    public void help(View v){
        /*
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Hello, this is the BMI Calculator.");
        builder.setTitle("BMI calculator");
        builder.setPositiveButton("OK", null);
        builder.setNegativeButton("No", null);
        builder.setNeutralButton("Cancel", null);
        builder.show();
        */

        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.app_name))
                .setMessage(getString(R.string.dialog_messate))
                .setPositiveButton(getString(R.string.button_ok), null)
                .setNegativeButton(getString(R.string.button_no), null)
                .setNeutralButton(getString(R.string.button_cancel), null)
                .show();

    }

}
