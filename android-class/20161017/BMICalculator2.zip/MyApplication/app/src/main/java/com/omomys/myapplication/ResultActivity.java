package com.omomys.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        TextView message =  (TextView) findViewById(R.id.message);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String messageText = bundle.getString("message");
        Double b = bundle.getDouble("bmi", 0);
        message.setText(messageText.toString() + ": " + Double.toString(b));
    }
}
