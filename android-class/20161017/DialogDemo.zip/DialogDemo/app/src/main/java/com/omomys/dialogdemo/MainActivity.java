package com.omomys.dialogdemo;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onButtonClick(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        switch(view.getId()){
            case R.id.btn_aldia_etbtn:
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setTitle("文字輸入對話框").setMessage("請輸入姓名：");
                final EditText et = new EditText(MainActivity.this);
                builder.setView(et);
                builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        String message = et.getText().toString();
                        Toast.makeText(MainActivity.this, "文字輸入對話框 " + message, Toast.LENGTH_SHORT).show();
                    }
                });

                builder.create().show();
                break;

            case R.id.btn_aldia_3btn:
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setMessage("內容區").setTitle("三鍵對話框");
                builder.setNeutralButton("中立", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "三鍵對話框-中立", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "三鍵對話框-確定", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("否定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "三鍵對話框-否定", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.create().show();
                break;

            case R.id.btn_aldia_single:
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setTitle("單選對話框");
                builder.setSingleChoiceItems(R.array.agree, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        List<String> list = Arrays.asList(getResources().getStringArray(R.array.agree));
                        Toast.makeText(MainActivity.this, "單選對話框-" + list.get(which), Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "單選對話框-取消", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.create().show();
                break;

            case R.id.btn_aldia_multi:
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setTitle("多選對話框");
                final String[] agreeList = getResources().getStringArray(R.array.agree);
                final boolean[] checkList = new boolean[agreeList.length];

                builder.setMultiChoiceItems(agreeList, checkList, new DialogInterface.OnMultiChoiceClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        checkList[which] = isChecked;
                    }
                });

                builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        StringBuilder sb = new StringBuilder();
                        for(int i=0; i< checkList.length; i++){
                            if(checkList[i])
                                sb.append(agreeList[i] + ", ");
                        }
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "多選對話框-確定 " + sb.toString(), Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "多選對話框-取消", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.create().show();
                break;

            case R.id.btn_aldia_list:
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setTitle("列表對話框");
                builder.setItems(R.array.agree, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        List<String> list = Arrays.asList(getResources().getStringArray(R.array.agree));
                        Toast.makeText(MainActivity.this, "列表對話框-" + list.get(which), Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "列表對話框-取消", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.create().show();
                break;

            case R.id.btn_aldia_progress:
                ProgressDialog pDialog = new ProgressDialog(this);
                pDialog.setCancelable(true);
                pDialog.setMessage("進度對話框");
                pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                //pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                pDialog.show();
                new DialogThread(pDialog).start();

                break;
            case R.id.btn_aldia_customize:
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setTitle("自定佈局對話框");

                LayoutInflater inflater = getLayoutInflater();

                ViewGroup layout = (ViewGroup) inflater.inflate(R.layout.dialog_layout, (ViewGroup) findViewById(R.id.root));

                final TextView tv = (TextView)layout.getChildAt(0);

                builder.setView(layout);

                builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "自定佈局對話框-確定 " + tv.getText().toString(), Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "自定佈局對話框-取消", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.create().show();
                break;

            case R.id.btn_aldia_datepicker:
                DatePickerDialog dpd = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(String.valueOf(year) + " 年 ");
                        sb.append(String.valueOf(monthOfYear) + " 月 ");
                        sb.append(String.valueOf(dayOfMonth) + " 日");
                        Toast.makeText(MainActivity.this, "挑選日期對話框-" + sb.toString(), Toast.LENGTH_SHORT).show();
                    }
                }, 2015, 11, 11);
                dpd.show();
                break;
            case R.id.btn_aldia_timepicker:
                TimePickerDialog tpd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hour, int minutes) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(String.valueOf(hour) + " 時 ");
                        sb.append(String.valueOf(minutes) + " 分");
                        Toast.makeText(MainActivity.this, "挑選時間對話框-" + sb.toString(), Toast.LENGTH_SHORT).show();
                    }
                }, 12, 00, true);
                tpd.show();
                break;

            case R.id.btn_diafrag:
                final DemoDialogFragment ddf = new DemoDialogFragment();
                    ddf.show(getFragmentManager(), "對話框版塊");
                break;
        }
    }

    public void genANumber(View view){
        ViewGroup vg = (ViewGroup) view.getParent();
        TextView tv = (TextView) vg.getChildAt(0);
        tv.setText(String.valueOf(Math.floor(Math.random() * 100)));
    }

    private class DialogThread extends Thread{
        private ProgressDialog dialog;
        private int count;

        DialogThread(ProgressDialog dialog){
            this.dialog = dialog;
            count = 0;
        }

        @Override
        public void run(){
            /*
            while(count < 2000000){
                count++;
                dialog.setProgress((int)(count/20000));
            }
            dialog.dismiss();
            */
            try{
                Thread.sleep(5000);
            }
            catch(Exception e) {
                e.printStackTrace();
            }
            finally {
                dialog.dismiss();
            }
        }
    }
}
