package com.omomys.dialogdemo;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Created by Bob on 2015/11/12.
 */
public class DemoDialogFragment extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder ab = new AlertDialog.Builder(getActivity());
        ab.setTitle("對話框版塊")
                .setMessage("這是對話框版塊的內容區")
                .setPositiveButton("確定", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Toast.makeText(DemoDialogFragment.this.getActivity(), "對話框版塊-確定", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Toast.makeText(DemoDialogFragment.this.getActivity(), "對話框版塊-取消", Toast.LENGTH_SHORT).show();
                    }
                });
        return ab.create();
    }
}
