package com.omomys.httpurlconnectiondemo;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {

    private TextView url;
    private TextView response;
    private Handler handler;
    private Thread connThread;
    private Runnable task;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        handler = new Handler();
        connThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("http://atm.snpy.org/get?id=123&func=abc");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.connect();
                    InputStreamReader reader = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    int data = reader.read();
                    String inData = "";
                    while(data != -1){
                        inData += (char)data;
                        data = reader.read();
                    }

                    final String message = "Message: " + conn.getResponseMessage() + " Response Code: " + String.valueOf(conn.getResponseCode());

                    reader.close();
                    final String outData = inData;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            response.setText(outData);
                            Snackbar.make(toolbar, message, Snackbar.LENGTH_SHORT).show();
                        }
                    });
/*
                    URL url = new URL("http://atm.snpy.org/get?id=123&func=abc");
                    URLConnection conn = url.openConnection();
                    InputStreamReader reader = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    int data = reader.read();
                    String inData = "";
                    while(data != -1){
                        inData += (char)data;
                        data = reader.read();
                    }
                    reader.close();
                    final String outData = inData;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            response.setText(outData);
                        }
                    });
*/
                } catch(MalformedURLException err) {
                    err.printStackTrace();
                } catch(IOException err) {
                    err.printStackTrace();
                }
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connThread.start();
            }
        });

        setupUI();
    }

    private void setupUI() {
        url = (TextView) findViewById(R.id.tv_url);
        response = (TextView) findViewById(R.id.tv_response);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
