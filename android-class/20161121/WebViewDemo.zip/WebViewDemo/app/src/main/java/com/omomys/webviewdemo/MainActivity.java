package com.omomys.webviewdemo;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private WebView wv;
    private String homeUrl;
    private EditText et;
    private InputMethodManager im;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Activity act = this;
        im = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        et = (EditText) findViewById(R.id.url);
        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                im.hideSoftInputFromWindow(v.getWindowToken(), 0);
                homeUrl = v.getText().toString();
                wv.loadUrl(homeUrl);
                return true;
            }
        });
        homeUrl = getResources().getString(R.string.home_url);
        wv = (WebView) findViewById(R.id.web_view);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.canGoBackOrForward(10);
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient());
        wv.requestFocus(); //get focus on webview not on the edittext
        wv.loadUrl(homeUrl);
    }

    public void onHome(View view){
        wv.loadUrl(homeUrl);
    }

    public void moveForward(View view){
        if(wv.canGoForward())
            wv.goForward();
    }

    public void moveBackward(View view){
        if(wv.canGoBack())
            wv.goBack();
    }
}
