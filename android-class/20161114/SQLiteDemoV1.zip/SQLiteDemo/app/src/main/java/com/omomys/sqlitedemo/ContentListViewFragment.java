package com.omomys.sqlitedemo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.ListViewCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CursorAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ContentListViewFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 *
 */
public class ContentListViewFragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    private ListViewCompat clv;
    private String[] contentListViewItem;
    private ArrayAdapter<String> contentAdapter;
    private DBHelper dbHelper;
    private SQLiteDatabase db;
    private SimpleCursorAdapter sca;
    private Cursor contentListCursor;
    private SwipeRefreshLayout swrLayout;

    public ContentListViewFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_content_list_view, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState){

        super.onActivityCreated(savedInstanceState);
        clv = (ListViewCompat) getView().findViewById(R.id.content_listview);
        clv.setEmptyView(getView().findViewById(R.id.empty_list_view));
        clv.setOnItemClickListener(new OnContentListItemClick());

        swrLayout = (SwipeRefreshLayout) getView().findViewById(R.id.swipe_refreash_layout);
        swrLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                contentListCursor = db.rawQuery("select * from apps", null);
                if(contentListCursor != null) {
                    //Log.i("omomys", String.valueOf(contentListCursor.getCount()));
                    sca = new SimpleCursorAdapter(getActivity(), R.layout.content_list_item, contentListCursor,
                            new String[]{"name", "price", "created_date"}, new int[]{R.id.content_list_item_name,
                            R.id.content_list_item_price, R.id.content_list_item_date},
                            CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
                    clv.setAdapter(sca);
                    sca.notifyDataSetChanged();
                }
                swrLayout.setRefreshing(false);
            }
        });

        dbHelper = new DBHelper(getActivity(), "demo", 3);
        db = dbHelper.getReadableDatabase();
        onReflashListView();
    }

    public void onReflashListView(){
        contentListCursor = db.rawQuery("select * from apps", null);
        if(contentListCursor != null) {
            Log.i("omomys", String.valueOf(contentListCursor.getCount()));
            sca = new SimpleCursorAdapter(getActivity(), R.layout.content_list_item, contentListCursor,
                    new String[]{"name", "price", "created_date"}, new int[]{R.id.content_list_item_name,
                    R.id.content_list_item_price, R.id.content_list_item_date},
                    CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
            clv.setAdapter(sca);
            sca.notifyDataSetChanged();
        }
    }

    @Override
    public void onStop(){
        contentListCursor.close();
        db.close();
        super.onStop();
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(String str) {
        if (mListener != null) {
            mListener.onFragmentCLVInteraction(str);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private class OnContentListItemClick implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            //String item = (String) parent.getItemAtPosition(position);
            //Toast.makeText(getView().getContext(), item, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentCLVInteraction(String str);
    }
}
