package com.omomys.sqlitedemo;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements
        DetailViewFragment.OnFragmentInteractionListener,
        DrawerListViewFragment.OnFragmentInteractionListener,
        ContentListViewFragment.OnFragmentInteractionListener {

    private Toolbar tb;
    private boolean tbStateHome;
    private ActionBarDrawerToggle dt;
    private DrawerLayout dl;
    private ContentListViewFragment cFrag;
    private DetailViewFragment dFrag;
    private FragmentManager fm;
    private FragmentTransaction ft;
    private DBHelper dbHelper;
    private SQLiteDatabase db;
    private static final int DB_VERSION = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tb = (Toolbar) findViewById(R.id.toobar);
        setSupportActionBar(tb);

        dl = (DrawerLayout) findViewById(R.id.drawer_layout);
        dt = new ActionBarDrawerToggle(this, dl, tb, R.string.open_drawer_des, R.string.close_drawer_des);
        dt.syncState();

        tbStateHome = true;

        cFrag = new ContentListViewFragment();
        dFrag = new DetailViewFragment();

        fm = getFragmentManager();
        ft = fm.beginTransaction();
        ft.replace(R.id.fragment_container, cFrag);
        ft.commit();

    }

    @Override
    public void onStart(){
        super.onStart();
        dbHelper = new DBHelper(this, "demo", DB_VERSION);
        db = dbHelper.getReadableDatabase();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.tool_bar_menu, menu);

        if(tbStateHome) {
            menu.findItem(R.id.menu_item_save).setVisible(false);
            menu.findItem(R.id.menu_item_back).setVisible(false);
            menu.findItem(R.id.menu_item_new_record).setVisible(true);
        }
        else{
            menu.findItem(R.id.menu_item_save).setVisible(true);
            menu.findItem(R.id.menu_item_back).setVisible(true);
            menu.findItem(R.id.menu_item_new_record).setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == R.id.menu_item_new_record){
            ft = fm.beginTransaction();
            ft.replace(R.id.fragment_container, dFrag);
            ft.addToBackStack(null);
            ft.commit();
            tbStateHome = false;
            invalidateOptionsMenu();
        }

        if(item.getItemId() == R.id.menu_item_back){
            fm.popBackStack();
            tbStateHome = true;
            invalidateOptionsMenu();
            hideSoftKeyboard();
        }

        if(item.getItemId() == R.id.menu_item_save){
            dFrag.writeToDB(); //write data into DB
            tbStateHome = true;
            invalidateOptionsMenu();
            fm.popBackStack();
        }
        return true;
    }

    public void onFragmentDLVInteraction(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }

    public void onFragmentCLVInteraction(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }

    public void onFragmentDtlInteraction(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onStop(){
        db.close();
        super.onStop();
    }

    public SQLiteDatabase db(){
        return db;
    }

    public void hideSoftKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager)  MainActivity.this.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(MainActivity.this.getCurrentFocus().getWindowToken(), 0);
    }

    public void onTakePicture(View view){
            dFrag.onTakePicture(view);
    }
}


