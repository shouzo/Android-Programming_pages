package com.omomys.sqlitedemo;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.ListViewCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link DrawerListViewFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class DrawerListViewFragment extends Fragment implements View.OnClickListener{

    private OnFragmentInteractionListener mListener;
    private ListViewCompat dlv;
    private String[] drawerListViewItem;
    private ArrayAdapter<String> drawerAdapter;

    public DrawerListViewFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_drawer_list_view, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        dlv = (ListViewCompat) getView().findViewById(R.id.drawer_listview);
        dlv.setOnItemClickListener(new OnDrawerListItemClick());
        drawerListViewItem = getResources().getStringArray(R.array.drawer_list);
        drawerAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, drawerListViewItem);
        dlv.setAdapter(drawerAdapter);
    }

    @Override
    public void onClick(View view){

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(String str) {
        if (mListener != null) {
            mListener.onFragmentDLVInteraction(str);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentDLVInteraction(String str);
    }

    private class OnDrawerListItemClick implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            String item = (String) parent.getItemAtPosition(position);
            Toast.makeText(getView().getContext(), item, Toast.LENGTH_SHORT).show();
        }
    }
}
