package com.omomys.jsondemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Spinner sp_employee, sp_product;
    private TextView tv_employee, tv_product;
    private String jsonStr;
    private ArrayAdapter<String> adp_employee, adp_product;
    private ArrayList<String> employeeId, productId, employeeName, productName;
    private ArrayList<String> employeeSalary, productPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp_employee = (Spinner)findViewById(R.id.sp_employee);
        sp_product = (Spinner)findViewById(R.id.sp_product);
        tv_employee = (TextView)findViewById(R.id.tv_emplyee);
        tv_product = (TextView)findViewById(R.id.tv_product);
        jsonStr = getResources().getString(R.string.company);
        employeeId = new ArrayList<String>();
        productId = new ArrayList<String>();
        employeeName = new ArrayList<String>();
        productName = new ArrayList<String>();
        employeeSalary = new ArrayList<String>();
        productPrice = new ArrayList<String>();

        try {
            JSONObject jsRootObj = new JSONObject(jsonStr);
            JSONArray jsEmployeeArray = jsRootObj.optJSONArray("Employee");
            JSONArray jsProductArray = jsRootObj.optJSONArray("Product");
            for(int i=0; i<jsEmployeeArray.length(); i++){
                JSONObject jsEmployee = jsEmployeeArray.getJSONObject(i);
                employeeId.add(jsEmployee.optString("id"));
                employeeName.add(jsEmployee.optString("name"));
                employeeSalary.add(jsEmployee.optString("salary"));
                //Toast.makeText(this, jsEmployee.getString("name"), Toast.LENGTH_SHORT).show();
            }
            for(int i=0; i<jsProductArray.length(); i++){
                JSONObject jsProduct = jsProductArray.getJSONObject(i);
                productId.add(jsProduct.optString("id"));
                productName.add(jsProduct.optString("name"));
                productPrice.add(jsProduct.optString("salary"));
                //Toast.makeText(this, jsProduct.opt("name").toString(), Toast.LENGTH_SHORT).show();
            }

        }catch(JSONException e){
            Toast.makeText(this, jsonStr, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        adp_employee = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, employeeName);
        adp_product = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, productName);

        sp_employee.setAdapter(adp_employee);
        sp_product.setAdapter(adp_product);


        sp_employee.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String str = parent.getItemAtPosition(position).toString();
                tv_employee.setText(str);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        sp_product.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String str = parent.getItemAtPosition(position).toString();
                tv_product.setText(str);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}
