package com.omomys.listviewsqlitedemo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewItemActivity extends AppCompatActivity {

    private EditText etName, etPhone, etAddress;
    private DBHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);
        etName = (EditText) findViewById(R.id.et_name);
        etPhone = (EditText) findViewById(R.id.et_phone);
        etAddress = (EditText) findViewById(R.id.et_address);
    }

    public void newItem(View view){

        dbHelper = DBHelper.getInstance(this, "contactsDB", 1);
        db = dbHelper.getWritableDatabase();
        String name = etName.getText().toString();
        String phone = etPhone.getText().toString();
        String address = etAddress.getText().toString();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("phone", phone);
        Long id = db.insert("contacts", null, values);
        Log.i("ADD: ", String.valueOf(id));
        //String sql = "INSERT INTO contacts (_id, name, phone, address, created_time) VALUES (null, '" +
               // name + "', '" + phone + "', '" + address + "'," + null + ")";
        //Cursor cursor = db.rawQuery(sql, null);
        //Log.i("ADD: ", String.valueOf(cursor.getInt(0)));
    }
}
