package com.omomys.cp;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickAddMember(View view){
        ContentValues values = new ContentValues();
        values.put(CPMember.NAME, ((EditText)findViewById(R.id.member_name)).getText().toString());

        Uri uri = getContentResolver().insert(CPMember.CONTENT_URI, values);

        Toast.makeText(this, uri.toString(), Toast.LENGTH_SHORT).show();
    }

    public void onClickRetrieveMember(View view){
        String URL = "content://com.omomys.provider.data/member";

        Uri members = Uri.parse(URL);
        Cursor c = managedQuery(members, null, null, null, "name");

        if(c.moveToFirst()){
            do{
                Toast.makeText(this, c.getString(c.getColumnIndex(CPMember.ID))+"."+
                c.getString(c.getColumnIndex(CPMember.NAME)), Toast.LENGTH_SHORT).show();
            } while(c.moveToNext());
        }
    }
}
