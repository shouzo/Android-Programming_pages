package com.omomys.fragmentdemo;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements FirstFragment.OnFragmentFInteractionListener,
    SecondFragment.OnFragmentSInteractionListener{

    //private FragmentManager fragmentManager;
    //private FragmentTransaction fragmentTransaction;
    private TextView tv;
    //private LinearLayout fragLayout;
    private int whichFragment = 1;
    private FirstFragment fragment1;
    private SecondFragment fragment2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.activity_tv);
        fragment1 = new FirstFragment();
        fragment2 = new SecondFragment();
/*
        FirstFragment fragment = new FirstFragment();
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_container, fragment);
        fragmentTransaction.commit();
*/
    }
    public void onButtonClick(View view){
        FragmentTransaction fragTrans = getFragmentManager().beginTransaction();
        switch(whichFragment){
            case 1:
                fragTrans.replace(R.id.fragment_first, fragment1, "frag_first");
                whichFragment = 2;
                break;
            case 2:
                fragTrans.replace(R.id.fragment_first, fragment2, "frag_second");
                whichFragment = 1;
                break;
        }
        fragTrans.commit();
    }

    @Override
    public void onFragmentFInteraction(View view){
        tv.setText("bingo");
    }

    public void onFragmentSInteraction(View view){
        tv.setText("bingo");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
    }
}
