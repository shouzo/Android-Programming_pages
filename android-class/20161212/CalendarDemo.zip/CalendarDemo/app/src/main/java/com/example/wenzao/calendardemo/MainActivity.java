package com.example.wenzao.calendardemo;

import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.DatePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    public CalendarView cv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cv = (CalendarView) findViewById(R.id.calendarView);
        cv.setShowWeekNumber(true);
        cv.setFirstDayOfWeek(2);
        cv.setOnDateChangeListener(new OnDateChanged());

    }

    public class OnDateChanged implements CalendarView.OnDateChangeListener{
        @Override
        public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
            String str = "您所選的日期為: " + year + "/" + month + "/" + dayOfMonth;
            Snackbar.make(view, str, Snackbar.LENGTH_SHORT).show();
        }
    }
}
