package com.omomys.menudemo;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.res.Resources;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private FourCardsFragment fcf;
    private NineCardsFragment ncf;
    private FragmentManager fm;
    private FragmentTransaction ft;
    private DrawerLayout drawerL;
    private ActionBarDrawerToggle dt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar tb = (Toolbar)findViewById(R.id.tb_bob);
        setSupportActionBar(tb);
        tb.setSubtitle("omomys");
        //tb.setOverflowIcon(getDrawable(R.drawable.ic_android_black_24dp));

        drawerL = (DrawerLayout)findViewById(R.id.drawer);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        dt = new ActionBarDrawerToggle(this, drawerL, tb, R.string.drawer_open_description,
                                R.string.drawer_close_description);
        dt.syncState();
        drawerL.setDrawerListener(dt);

        fcf = new FourCardsFragment();
        ncf = new NineCardsFragment();
        fm = getFragmentManager();
        RelativeLayout ll= (RelativeLayout) findViewById(R.id.layout_frag);
        registerForContextMenu(ll);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.app_bar_menu, menu);
        SubMenu sm = menu.addSubMenu(0, Menu.FIRST, 2, "子選單");
        menu.add(0, Menu.FIRST+1, 0, "4 Cards");
        menu.add(0, Menu.FIRST+2, 1, "9 Cards");
        sm.add(1, Menu.FIRST+3, Menu.NONE, "子項1");
        sm.add(1, Menu.FIRST + 4, Menu.NONE, "子項2");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        ft = fm.beginTransaction();
        switch(item.getItemId()){
            case Menu.FIRST+1:
                //4 cards
                ft.replace(R.id.layout_frag, fcf);
                ft.commit();
                break;
            case Menu.FIRST+2:
                //9 cards
                ft.replace(R.id.layout_frag, ncf);
                ft.commit();
                break;
            case Menu.FIRST+3:
                //sub item 1
                Toast.makeText(this, "item 1 pressed", Toast.LENGTH_SHORT).show();
                break;
            case Menu.FIRST+4:
                //sub item 2
                Toast.makeText(this, "item 2 pressed", Toast.LENGTH_SHORT).show();
                break;
            case R.id.app_bar_action_print:
            case R.id.app_bar_action_setting:
            case R.id.search1:
            case R.id.search2:
                Toast.makeText(this, String.valueOf(item.getItemId()), Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        switch(view.getId()){
            case R.id.layout_frag:
                menu.add(0, 0, 0, "情境選單項目1");
                menu.add(0, 0, 1, "情境選單項目2");
                break;
        }
    }
    @Override
    public boolean onContextItemSelected(MenuItem item){
        switch(item.getItemId()){
            case 0:
            case 1:
                Toast.makeText(this, item.getTitle().toString(), Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onContextItemSelected(item) ;
    }

    public void onButtonClick(View view){
        if(drawerL.isDrawerOpen(Gravity.LEFT))
            drawerL.closeDrawer(Gravity.LEFT);
        Toast.makeText(this, "Drawer Button is Clicked.", Toast.LENGTH_SHORT).show();
    }
}
