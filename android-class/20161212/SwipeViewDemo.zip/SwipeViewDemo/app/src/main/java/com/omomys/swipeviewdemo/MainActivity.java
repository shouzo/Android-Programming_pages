package com.omomys.swipeviewdemo;

import android.app.ActionBar;
import android.net.Uri;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements ListFragment.OnFragmentInteractionListener{

    private FragmentManager fragMam;
    private FragmentPagerAdapter fragPagerAdapter;
    private ViewPager vp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        fragMam = getSupportFragmentManager();

        fragPagerAdapter = new FragmentPagerAdapter(fragMam) {
            @Override
            public Fragment getItem(int position) {
                return new ListFragment();
            }

            @Override
            public String getPageTitle(int position){
                String title = "";
                switch(position){
                    case 0:
                        title = "第一個頁籤";
                        break;
                    case 1:
                        title = "第二個頁籤";
                        break;
                    case 2:
                        title = "第三個頁籤";
                        break;
                }
                return title;
            }

            @Override
            public int getCount() {
                return 3;
            }
        };

        vp = (ViewPager) findViewById(R.id.view_pager);
        vp.setAdapter(fragPagerAdapter);

    }

    public void onFragmentInteraction(String str){

    }
}
