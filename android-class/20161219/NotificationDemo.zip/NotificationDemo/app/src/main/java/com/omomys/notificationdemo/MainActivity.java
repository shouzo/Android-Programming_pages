package com.omomys.notificationdemo;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.opengl.Visibility;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private final int NOTIFICATION_ID = 1;
    private NotificationManager ntm;
    private Notification nti;
    private NotificationCompat.Builder buder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ntm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    @Override
    protected void onResume(){
        super.onResume();
        Intent intent = this.getIntent();
        try{
            String str = intent.getStringExtra("HI");
            if (!str.isEmpty())
                Toast.makeText(this, intent.getStringExtra("HI"), Toast.LENGTH_SHORT).show();
        }
        catch(Exception e){
            //e.printStackTrace();
        }
    }

    public void onPostNotification(View view){
        long[] vb = { 1000, 1000, 1000, 1000, 500, 200 };
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("HI", "Hi, this is Bob.");
        PendingIntent pendInt = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        buder = new NotificationCompat.Builder(this)
                .setAutoCancel(true)
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Hey, BigText"))
                .setContentTitle("Notification Title Here")
                .setContentText("Notification Text Here")
                .setSubText("Notification Subtext Here")
                .setTicker("Hi, ticker")
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setSmallIcon(R.drawable.ic_adb_white_24dp)
                .setContentIntent(pendInt)
                .setPriority(Notification.PRIORITY_HIGH)
                .setVibrate(vb);
        nti = buder.build();
        ntm.notify(NOTIFICATION_ID, nti);

    }

    @Override
    protected void onDestroy(){
        //ntm.cancel(NOTIFICATION_ID);
        super.onDestroy();
    }
}
