package com.omomys.broadcastreceiverdemo;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private BCReceiver bcr;
    private IntentFilter inf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bcr = new BCReceiver();
        inf = new IntentFilter();
        inf.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(bcr, inf);

    }

    public void onSendBroadcast(View view){
        Intent intent = new Intent();
        intent.setAction("BobAction");
        sendBroadcast(intent);
    }

    public void onPostNotification(View view){
        NotificationManager ntfm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder nb = new NotificationCompat.Builder(this);
        //int requestCode = 1;
        //Bitmap bmp = BitmapFactory.decodeResource(getResources(), R.drawable.building);
        long[] vib = { 50, 400, 200, 400, 50, 400 };
        nb.setSmallIcon(R.drawable.ic_adb_black_24dp)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
                .setContentTitle("Notification from Bob")
                .setContentText("Hi, It's time to write a program.")
                .setVibrate(vib)
                .setAutoCancel(true)
                .setLights(0xffffffff, 3000, 1000)
                .setCategory(NotificationCompat.CATEGORY_PROMO)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        //Intent intent = new Intent(this, MainActivity.class);
        //PendingIntent pintent = new PendingIntent.getActivity(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        //nb.setContentIntent(pintent);
        Notification noti = nb.build();
        ntfm.notify(1, noti);
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        unregisterReceiver(bcr);
    }

}
