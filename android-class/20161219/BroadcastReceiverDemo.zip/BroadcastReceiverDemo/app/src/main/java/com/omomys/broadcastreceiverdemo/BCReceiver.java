package com.omomys.broadcastreceiverdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class BCReceiver extends BroadcastReceiver {
    public BCReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        switch(intent.getAction()){
            case Intent.ACTION_POWER_CONNECTED:
                Log.i("Omomys", "External power is connected.");
                Toast.makeText(context, "External power is connected.", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_AIRPLANE_MODE_CHANGED:
                Log.i("Omomys", "Airplane mode is changed");
                Toast.makeText(context, "Airplane mode is changed.", Toast.LENGTH_SHORT).show();
                break;
            case "BobAction":
                Log.i("Omomys", "BobAction broadcast is received.");
                Toast.makeText(context, "BobAction broadcast is received.", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
