package com.omomys.dynamicbroadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class DynamicBroadcastReceiver extends BroadcastReceiver {

    private MainActivity host;

    public DynamicBroadcastReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        host.setMessage("There is a broadcast received!");
        Toast.makeText(context, "There is a broadcast received!", Toast.LENGTH_SHORT).show();
    }

    public void setHostActivity(MainActivity hostActivity){
        host = hostActivity;
    }

    public interface setMessageInterface{
        public void setMessage(String message);
    }
}
