package com.omomys.dynamicbroadcastreceiver;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements DynamicBroadcastReceiver.setMessageInterface {

    private DynamicBroadcastReceiver dReceiver;
    private TextView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dReceiver = new DynamicBroadcastReceiver();
        dReceiver.setHostActivity(this);
        message = (TextView) findViewById(R.id.message);
    }

    @Override
    protected void onStart(){
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.AIRPLANE_MODE");
        intentFilter.setPriority(500);
        registerReceiver(dReceiver, intentFilter);
    }

    @Override
    protected void onDestroy(){
        unregisterReceiver(dReceiver);
        super.onDestroy();
    }

    public void setMessage(String m){
        message.setText(m);
    }
}
