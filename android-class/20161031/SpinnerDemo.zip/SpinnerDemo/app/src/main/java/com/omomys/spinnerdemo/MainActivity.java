package com.omomys.spinnerdemo;

import android.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatSpinner;
import android.text.Layout;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private Spinner sp1, sp2, sp3;
    private TextView spTv, itemTv, sp3Tv;
    private String[] items = {"4", "5", "6"};
    private RelativeLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout = (RelativeLayout) findViewById(R.id.rl);


        sp1 = (Spinner) findViewById(R.id.spinner);
        sp2 = (Spinner) findViewById(R.id.spinner2);

        sp3Tv = new TextView(this);
        sp3Tv.setText("Spinner 3");
        sp3Tv.setTextSize(32);
        sp3Tv.setX(0);
        sp3Tv.setY(520);
        layout.addView(sp3Tv);

        sp3 = new AppCompatSpinner(this, Spinner.MODE_DROPDOWN);
        sp3.setX(0);
        sp3.setY(610);
        layout.addView(sp3);

        ArrayAdapter sp2Adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        sp2.setAdapter(sp2Adapter);

        ArrayAdapter sp3Adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        sp3.setAdapter(sp3Adapter);

        spTv = (TextView) findViewById(R.id.textView2);
        itemTv = (TextView) findViewById(R.id.textView4);

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String str = parent.getItemAtPosition(position).toString();
                spTv.setText("1");
                itemTv.setText(str);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String str = parent.getItemAtPosition(position).toString();
                spTv.setText("2");
                itemTv.setText(str);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sp3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String str = parent.getItemAtPosition(position).toString();
                spTv.setText("3");
                itemTv.setText(str);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
