package com.omomys.drawerlistviewdemo;

import android.app.ProgressDialog;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.renderscript.ScriptGroup;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class MainActivity extends AppCompatActivity {

    private Toolbar tb;
    private DrawerLayout dl;
    private ActionBarDrawerToggle dt;
    private ListView lv;
    private String[] mi;
    private ArrayAdapter ap;
    private TextView tv;
    private ProgressDialog pd;
    private final String hsString="http://data.kaohsiung.gov.tw/Opendata/DownLoad.aspx?Type=2&CaseNo1=AV&CaseNo2=1&FileType=1&Lang=C&FolderType=";
    private URL hsURL, erURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = (TextView)findViewById(R.id.content_textview);
        pd = new ProgressDialog(this);
        pd.setMessage("Connecting...");

        try {
            hsURL = new URL(hsString);
        }
        catch(MalformedURLException e){
            e.printStackTrace();
        }

        tb = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(tb);

        dl = (DrawerLayout)findViewById(R.id.drawer_layout);
        dt = new ActionBarDrawerToggle(this, dl, tb, R.string.open_description, R.string.close_description);
        dt.syncState();

        lv = (ListView)findViewById(R.id.drawer_listview);
        mi = getResources().getStringArray(R.array.list_items);
        ap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mi);
        lv.setAdapter(ap);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = (String)parent.getItemAtPosition(position);

                if(dl.isDrawerOpen(Gravity.START))
                    dl.closeDrawer(Gravity.START);

                Toast.makeText(MainActivity.this, item, Toast.LENGTH_SHORT).show();

                if(item.equals("HotSpots")) {
                    tv.setText("HotSpots is selected");

                    GetJSONAsyncTask jsonAsyncTask = new GetJSONAsyncTask();
                    jsonAsyncTask.execute(hsURL);

                }

                if(item.equals("Exchange Rate"))
                    tv.setText("Exchange Rate is selected");
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    class GetJSONAsyncTask extends AsyncTask<URL, Void, String>{
        @Override
        protected void onPreExecute(){
            pd.show();
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(URL... url){
            BufferedReader br = null;
            HttpURLConnection conn = null;
            StringBuilder json = new StringBuilder();
            String temp = null;
            try{
                conn = (HttpURLConnection) url[0].openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.connect();
                br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                while((temp = br.readLine())!= null){
                    json.append(temp);
                }
                br.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
            finally{
                conn.disconnect();
            }
            return json.toString();
        }
        @Override
        protected void onProgressUpdate(Void... foo){
        }
        @Override
        protected void onPostExecute(String str){
            pd.dismiss();
            tv.setText(str);
            super.onPostExecute(str);
        }
    }


}
