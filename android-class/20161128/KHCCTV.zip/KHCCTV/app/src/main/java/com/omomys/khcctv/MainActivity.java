package com.omomys.khcctv;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    String[] cctvArray;
    ProgressBar pb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView cctvList = (ListView) findViewById(R.id.lv_cctv_list);
        //ArrayAdapter<String> aAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, cctvArray);
        //cctvList.setAdapter(aAdapter);
        pb = (ProgressBar) findViewById(R.id.pb_progress);
        pb.setVisibility(View.INVISIBLE);
        BobAT bat = new BobAT(this);
        bat.execute();
    }

    public class BobAT extends AsyncTask<Void, Integer, String> {

        private Context atContext;

        public BobAT(Context context){
            atContext = context.getApplicationContext();
        }

        @Override
        protected void onPreExecute(){
            pb.setVisibility(View.VISIBLE);
            Toast.makeText(atContext, "AsyncTask is about to start.", Toast.LENGTH_SHORT).show();
        }

        protected String doInBackground(Void... params){
            String responseStr = "";
            try {
                URL url = new URL("http://xml11.kctmc.nat.gov.tw:8080/XML/cctv_value.xml");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(5000);
                conn.setConnectTimeout(5000);
                conn.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36");
                conn.setInstanceFollowRedirects(true);

                if( conn.getResponseCode() == HttpURLConnection.HTTP_OK ){

                    InputStream is = conn.getInputStream();
                    BufferedReader  bufferedReader  = new BufferedReader( new InputStreamReader(is) );

                    String tempStr;
                    StringBuffer stringBuffer = new StringBuffer();

                    while( ( tempStr = bufferedReader.readLine() ) != null ) {
                        stringBuffer.append( tempStr );
                    }

                    bufferedReader.close();
                    is.close();

                    String  mime = conn.getContentType();
                    boolean isMediaStream = false;

                    if( mime.indexOf("audio") == 0 ||  mime.indexOf("video") == 0 ){
                        isMediaStream = true;
                    }

                    responseStr = stringBuffer.toString();
                }

            } catch(MalformedURLException e){
                e.printStackTrace();
            } catch(IOException e){
                e.printStackTrace();
            }
                return responseStr;
        }

        @Override
        protected void onProgressUpdate(Integer... i){
            super.onProgressUpdate(i);
            //Toast.makeText(atContext, String.valueOf(i[0]), Toast.LENGTH_SHORT).show();
            //playTimes.setText(String.valueOf(i[0]));
        }

        @Override
        protected void onPostExecute(String str){
            super.onPostExecute(str);
            pb.setVisibility(View.INVISIBLE);
            Toast.makeText(atContext, str, Toast.LENGTH_SHORT).show();
        }

    }
}
