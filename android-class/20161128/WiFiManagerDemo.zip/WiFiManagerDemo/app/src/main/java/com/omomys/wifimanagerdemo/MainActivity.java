package com.omomys.wifimanagerdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ListViewCompat;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Switch;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WifiManager wifiManager;
    private Switch sw;
    private ListViewCompat lv;
    private WifiScanReceiver receiver;
    private ArrayAdapter<String> ssidAdapter;
    private String[] ssids;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListViewCompat) findViewById(R.id.ssid_listview);
        receiver = new WifiScanReceiver();
        wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        sw = (Switch) findViewById(R.id.wifi_switch);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    if (!wifiManager.isWifiEnabled()){
                        //enable wifi
                        wifiManager.setWifiEnabled(true);
                        wifiManager.startScan();
                    }
                } else {
                    if (wifiManager.isWifiEnabled()) {
                        //disable wifi
                        wifiManager.setWifiEnabled(false);
                    }
                }
            }
        });

        if(wifiManager.isWifiEnabled()){
            sw.setChecked(true);
            wifiManager.startScan();
        }
        else
            sw.setChecked(false);
    }

    @Override
    protected void onResume(){
        registerReceiver(receiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        registerReceiver(receiver, new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION));
        super.onResume();
    }

    @Override
    protected void onPause(){
        unregisterReceiver(receiver);
        super.onPause();
    }

    private class WifiScanReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context c, Intent intent){
            switch(intent.getAction()) {
                case WifiManager.SCAN_RESULTS_AVAILABLE_ACTION:
                    List<ScanResult> wifiList = wifiManager.getScanResults();
                    ssids = new String[wifiList.size()];
                    StringBuilder sb;
                    for (int i = 0; i < wifiList.size(); i++) {
                        sb = new StringBuilder();
                        sb.append("SSID: ");
                        sb.append(wifiList.get(i).SSID);
                        sb.append("   Level: ");
                        // >-35dBm 100%, =-65dBm 50%, =-95dBm 1%
                        if (Integer.valueOf(wifiList.get(i).level) >= -35)
                            sb.append("Excellent   < 3 m");

                        else if (Integer.valueOf(wifiList.get(i).level) < -35 &&
                                Integer.valueOf(wifiList.get(i).level) >= -50)
                            sb.append("Good   < 6 m");

                        else if(Integer.valueOf(wifiList.get(i).level)<-50 &&
                                Integer.valueOf(wifiList.get(i).level)>=-70)
                            sb.append("Medium   < 9 m");

                        else
                            sb.append("Bad   > 10 m");

                        ssids[i] = sb.toString();
                    }
                    ssidAdapter = new ArrayAdapter<String>(c, android.R.layout.simple_list_item_1, ssids);
                    lv.setAdapter(ssidAdapter);
                    break;

                case WifiManager.WIFI_STATE_CHANGED_ACTION:
                    int state = wifiManager.getWifiState();
                    switch(state){
                        case WifiManager.WIFI_STATE_DISABLED:
                            ssids = null;
                            ssidAdapter = null;
                            ssids = new String[0];
                            ssidAdapter = new ArrayAdapter<String>(c, android.R.layout.simple_list_item_1, ssids);
                            lv.setAdapter(ssidAdapter);
                            break;

                        case WifiManager.WIFI_STATE_DISABLING:
                        case WifiManager.WIFI_STATE_ENABLING:
                            break;

                        case WifiManager.WIFI_STATE_ENABLED:
                            wifiManager.startScan();
                            break;

                    }

            }
        }
    }
}
