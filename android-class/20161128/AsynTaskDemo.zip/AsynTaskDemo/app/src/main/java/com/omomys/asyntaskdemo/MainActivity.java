package com.omomys.asyntaskdemo;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView playTimes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playTimes = (TextView)findViewById(R.id.play_times);

        BobAT bat = new BobAT(this);

        bat.execute();
    }

    public void onButtonClick(View v){
        BobAT bat = new BobAT(this);
        bat.execute();
    }

    public class BobAT extends AsyncTask<Void, Integer, Void>{

        private Context atContext;

        public BobAT(Context context){
            atContext = context.getApplicationContext();
        }

        @Override
        protected void onPreExecute(){
            Toast.makeText(atContext, "AsyncTask is about to start.", Toast.LENGTH_SHORT).show();
        }

        protected Void doInBackground(Void... params){
            AudioAttributes at = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_GAME)
                     .build();

            SoundPool sp = new SoundPool.Builder()
                    .setMaxStreams(1)
                    .setAudioAttributes(at)
                    .build();

            int snd = sp.load(atContext, R.raw.scifi018, 1);

            //delay for loading sound clip
            try{
                Thread.sleep(1000);
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }

            for(int i=0; i<10; i++) {
                sp.play(snd, 1, 1, 0, 0, 1);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                publishProgress(i+1);
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... i){
            super.onProgressUpdate(i);
            //Toast.makeText(atContext, String.valueOf(i[0]), Toast.LENGTH_SHORT).show();
            playTimes.setText(String.valueOf(i[0]));
        }

        @Override
        protected void onPostExecute(Void i){
            super.onPostExecute(i);
            Toast.makeText(atContext, "AsyncTask is finished.", Toast.LENGTH_SHORT).show();
        }

    }
}
