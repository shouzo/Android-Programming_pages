package com.omomys.khcctv;

import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Xml;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> cctvArray;
    ArrayList<String> cctvUrlArray;
    ProgressBar pb;
    private ListView cctvList;
    private ArrayAdapter<String> aAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cctvList = (ListView) findViewById(R.id.lv_cctv_list);
        cctvArray = new ArrayList<String>();
        cctvUrlArray = new ArrayList<String>();
        aAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, cctvArray);
        cctvList.setAdapter(aAdapter);
        cctvList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                intent.putExtra("url", cctvUrlArray.get(i));
                startActivity(intent);
            }
        });
        pb = (ProgressBar) findViewById(R.id.pb_progress);
        pb.setVisibility(View.INVISIBLE);
        BobAT bat = new BobAT(this);
        bat.execute();
    }

    public class BobAT extends AsyncTask<Void, Integer, String> {

        private Context atContext;

        public BobAT(Context context){
            atContext = context.getApplicationContext();
        }

        @Override
        protected void onPreExecute(){
            pb.setVisibility(View.VISIBLE);
            Toast.makeText(atContext, "AsyncTask is about to start.", Toast.LENGTH_SHORT).show();
        }

        protected String doInBackground(Void... params){
            String responseStr = "";
            try {
                URL url = new URL("http://xml11.kctmc.nat.gov.tw:8080/XML/cctv_value.xml");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(5000);
                conn.setConnectTimeout(5000);
                conn.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36");
                conn.setInstanceFollowRedirects(true);

                if( conn.getResponseCode() == HttpURLConnection.HTTP_OK ){

                    InputStream is = conn.getInputStream();
                    BufferedReader  bufferedReader  = new BufferedReader( new InputStreamReader(is) );

                    String tempStr;
                    StringBuffer stringBuffer = new StringBuffer();

                    while( ( tempStr = bufferedReader.readLine() ) != null ) {
                        stringBuffer.append( tempStr );
                    }

                    bufferedReader.close();
                    is.close();

                    String  mime = conn.getContentType();
                    boolean isMediaStream = false;

                    if( mime.indexOf("audio") == 0 ||  mime.indexOf("video") == 0 ){
                        isMediaStream = true;
                    }

                    responseStr = stringBuffer.toString();
                }

            } catch(MalformedURLException e){
                e.printStackTrace();
            } catch(IOException e){
                e.printStackTrace();
            }
                return responseStr;
        }

        @Override
        protected void onProgressUpdate(Integer... i){
            super.onProgressUpdate(i);
            //Toast.makeText(atContext, String.valueOf(i[0]), Toast.LENGTH_SHORT).show();
            //playTimes.setText(String.valueOf(i[0]));
        }

        @Override
        protected void onPostExecute(String str){
            super.onPostExecute(str);
            pb.setVisibility(View.INVISIBLE);
            InputStream xmlStream = new ByteArrayInputStream(str.getBytes(StandardCharsets.UTF_8));

            try{
                XmlPullParserFactory xmlFactoryObject = XmlPullParserFactory.newInstance();
                XmlPullParser parser = xmlFactoryObject.newPullParser();

                parser.setInput(xmlStream, null);
                int event = parser.getEventType();
                while (event != XmlPullParser.END_DOCUMENT){
                    String name = parser.getName();
                    switch(event){
                        case XmlPullParser.START_TAG:
                            break;
                        case XmlPullParser.END_TAG:
                            if(name.equals("Info")){
                                cctvArray.add(parser.getAttributeValue(null, "cctvid"));
                                cctvUrlArray.add(parser.getAttributeValue(null, "url"));
                            }
                    }
                    event = parser.next();
                }

            } catch(Exception e){
                e.printStackTrace();
            }
            aAdapter.notifyDataSetChanged();
            //Toast.makeText(atContext, str, Toast.LENGTH_SHORT).show();
        }

    }

}
