package com.omomys.sharedpreferencesdemo;

import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private TextView name, id, age, score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (TextView) findViewById(R.id.name);
        id = (TextView) findViewById(R.id.id);
        age = (TextView) findViewById(R.id.age);
        score = (TextView) findViewById(R.id.score);

        //get data from shared preferences
        SharedPreferences sp = getPreferences(MODE_PRIVATE);
        name.setText(sp.getString("omomys_spdemo_name", "Bob"));
        id.setText(sp.getString("omomys_spdemo_id", "100100001"));
        age.setText(sp.getString("omomys_spdemo_age", "20"));
        score.setText(sp.getString("omomys_spdemo_score", "96"));
    }


    public void onSaveButtonClick(View view){
        SharedPreferences sp = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("omomys_spdemo_name", name.getText().toString());
        editor.putString("omomys_spdemo_id", id.getText().toString());
        editor.putString("omomys_spdemo_age", age.getText().toString());
        editor.putString("omomys_spdemo_score", score.getText().toString());
        editor.commit();
        Toast.makeText(this, "資料儲存成功", Toast.LENGTH_SHORT).show();
    }
}